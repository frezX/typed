from typed.typed import *
typed = TypedDecorator.typed
